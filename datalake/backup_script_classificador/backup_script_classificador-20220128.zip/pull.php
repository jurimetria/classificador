<?php `git pull`;


?>

<!DOCTYPE html>
<html lang="en">
<body>
.<br>
.<br>
.<br>
.<br>
........Pronto!<br>
.<br>
.<br>
.<br>
........O site CLASSIFICADOR foi atualizado com sucesso!<br>
.<br>
.<br>
.<br>
........Você já pode fechar esta página<br>
.<br>
.<br>
.<br>
.<br>
</body>
</html>