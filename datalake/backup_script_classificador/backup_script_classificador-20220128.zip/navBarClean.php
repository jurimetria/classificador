<?php $navBarClean=            "    <!-- BARRA DE NAVEGAÇÃO -->
    <div>

        <nav class='navbar navbar-expand-lg navbar-dark bg-dark'>

        <div>
            <img src='https://lp-classificador.s3.amazonaws.com/img/LogoBranco+-+P1.png'  alt='logo' width='80' height='80'>
        
        </div>

            <div class='container-fluid'>
                <a class='navbar-brand' href='index.php'>L&P | Classificador de Pastas</a>
                <button class='navbar-toggler ' type='button' data-bs-toggle='collapse' data-bs-target='#navbarNav' aria-controls='navbarNav' aria-expanded='false' aria-label='Toggle navigation'>
                    <span class='navbar-toggler-icon'></span>
                </button>
            </div>
<div class='container-fluid'><a style='color:gray'>Logado como: $logadoAvaliador</a></div>
<div class='container-fluid'></div>
<div class='container-fluid'></div>
<div class='container-fluid'></div>
            <div class='d-flex'>
            <p><a class='admUp' href='mailto:jurimetria@lp.com.br?subject=Classificador - dúvidas e sugestões' title='Contatar Administrador'> ✉  </a></p>
            </div>

            <!-- SAIR -->
            <div class='d-flex'>
                <a href='login.php' class='btn btn-danger me-5'>Sair</a>
            </div>
        </nav>
    </div><br>
    "
?>